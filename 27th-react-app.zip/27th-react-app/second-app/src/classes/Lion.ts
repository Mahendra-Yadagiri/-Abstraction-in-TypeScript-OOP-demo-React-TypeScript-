import Animal from "./Animal";

class Lion extends Animal{
    foodtaking: string="Eating Non-Veg";
    huntingBehaviour: string="Hunting Behaviour(Lion)-Hunt's deers  ";
    noOfTeeth: number=10;
    
    // sleepingBehavviour: void=
    // console.log("Lion-Sleeping Behaviour");
    
    noOfLegs: number=4;
    noOfNoses: number=1;

    constructor(){
        super();
        console.log("Inside lion Constructor");
        console.log(this.sleepingBehavviour);
        console.log(this.huntingBehaviour)
        
    }
    sleepingBehavviour:string="Sleeping Behaviour(Lion)-Forest places & Trees";
    

}
export default Lion;