abstract class Animal{
    noOfEyes:number=2;
    noOfTails:number=1;
    abstract noOfLegs:number;
    abstract noOfNoses:number;
    abstract noOfTeeth:number;

     abstract sleepingBehavviour:string;
     abstract huntingBehaviour:string;
     abstract foodtaking:string;
    foodBehaviour= ()=>{
        console.log("Eating Non-veg");
    }
    constructor(){
        console.log("Inside Animal Constructor")
    }
    

}
export default Animal;