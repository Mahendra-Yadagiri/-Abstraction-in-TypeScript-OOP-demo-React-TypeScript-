import Animal from "./Animal";

class Cat extends Animal{
    foodtaking: string="(Cat) Drinking Milk Eating Non-Veg & Veg";
    noOfLegs: number=4;
    noOfNoses: number=1;
    noOfTeeth: number=10;
    sleepingBehavviour: string="Sleeping Behaviour(Cat)-Top of Houses";
    huntingBehaviour: string=" Hunting Behavioue(Cat)-Hunt's rats";
    constructor(){
        super();
        console.log("Inside Cat Constructor");
        console.log(this.sleepingBehavviour);
        console.log(this.huntingBehaviour);
        console.log(this.foodtaking)

    }

}
export default Cat;