import Animal from "./Animal";

class Tiger extends Animal{
    foodtaking: string="Eating Non-Veg";
    huntingBehaviour: string="Hunting Behaviour(Tiger)-Hunt's deers";
    noOfTeeth: number=10;
    noOfLegs: number=4;
    noOfNoses: number=1;
    // sleepingBehavviour: void=
    // console.log("Tiger-Sleeping Behaviour");
    constructor(){
        super();
        console.log("Inside Tiger Constructor");
        console.log(this.sleepingBehavviour);
        console.log(this.huntingBehaviour)
       
    }
    sleepingBehavviour:string="Sleeping Behaviour(Tiger)-Forest places & Trees";
    

}
export default Tiger;