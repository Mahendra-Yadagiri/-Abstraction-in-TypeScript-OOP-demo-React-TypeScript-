import React from 'react';
import logo from './logo.svg';
import './App.css';
import Animal from './classes/Animal';
import Lion from './classes/Lion';
import Tiger from './classes/Tiger';
import Cat from './classes/Cat';

function App() {

  // let ranbinrKapoor = new Animal();
  let simha = new Lion();
  simha.foodBehaviour();
  let tiger= new Tiger();
  tiger.foodBehaviour();
  let cat = new Cat();
 
  
  return (
    <div className="App">
      <h1>Abstraction in TypeScript</h1>
    </div>
  );
}

export default App;
